﻿namespace CustomDependencyInjectionReaderAndWriter.Core.Contracts
{
    public interface IReader
    {
        string Read();
    }
}

﻿namespace CustomDependencyInjectionReaderAndWriter.Core.Contracts
{
    public interface IWriter
    {
        void Write(string content);
    }
}

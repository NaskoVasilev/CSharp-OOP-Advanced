﻿namespace ReaderAndWriter.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
